﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Annons_Applikation_Databasteknik
{
    public partial class AddAd : Form
    {
        public int userID { get; set; }
        Ad ad = new Ad();

        public AddAd(int _userID)
        {
            userID = _userID;
            InitializeComponent();
            GetCategories();
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string category = cbxCategory.SelectedItem.ToString();
            Connection c = new Connection();
            SqlConnection conn = c.GetConn();
            ad.AddNewAd(tbxTitle.Text, tbxDescription.Text, int.Parse(tbxCost.Text), category,conn,userID);
        }

        public void GetCategories()
        {
            List<string> Categories = ad.GetCategories();
            foreach (string str in Categories)
            {
                cbxCategory.Items.Add(str);
            }

        }
    }
}
