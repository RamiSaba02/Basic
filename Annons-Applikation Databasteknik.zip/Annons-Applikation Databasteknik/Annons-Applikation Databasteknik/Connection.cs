﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;

namespace Annons_Applikation_Databasteknik
{
    class Connection
    {
        public string _sqlConnectionStr = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        SqlConnection conn;
        public Connection()
        {
            conn = new SqlConnection(_sqlConnectionStr);

        }

        public SqlConnection GetConn()
        {
            return conn;
        }

    }
}
