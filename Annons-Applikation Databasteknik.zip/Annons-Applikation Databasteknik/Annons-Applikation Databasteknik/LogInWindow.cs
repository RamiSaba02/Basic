﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Annons_Applikation_Databasteknik
{
    public partial class LogInWindow : Form
    {

        public NewUserWindow nuw = new NewUserWindow();
        public string _sqlConnectionStr = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        SqlConnection conn;
        int userID = 0;
        bool correctLoginInfo = false;
        public LogInWindow()
        {
            conn = new SqlConnection(_sqlConnectionStr);
            InitializeComponent();
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            nuw.Show();
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            User user = new User(tbxUserName.Text, tbxPassword.Text, conn);
            userID = user.CheckLoginInfo();
            
            if (userID != 0)
            {
                MainApp MA = new MainApp(tbxUserName.Text, userID, conn);
                MA.Show();
                this.Hide();
            }
            

        }

        private void btnDontLogIn_Click(object sender, EventArgs e)
        {
            MainApp MA = new MainApp(tbxUserName.Text, userID, conn);
            MA.Show();
            this.Hide();

        }
    }
}
