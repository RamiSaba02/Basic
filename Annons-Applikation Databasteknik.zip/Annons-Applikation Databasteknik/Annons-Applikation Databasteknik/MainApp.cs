﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Annons_Applikation_Databasteknik
{
    public partial class MainApp : Form
    {
        public string LoggedInUsername { get; set; }
        public int UserID { get; set; }
        public SqlConnection _conn { get; set; }
        Ad ads = new Ad();
        List<string> ToLBX = new List<string>();

        public MainApp(string loggedInUsername, int userID, SqlConnection conn)
        {

            LoggedInUsername = loggedInUsername;
            UserID = userID;
            _conn = conn;
            InitializeComponent();
            GetCategories();
            cbxSort.Items.Add("Senaste");
            cbxSort.Items.Add("Äldsta");
            cbxSort.Items.Add("Dyraste");
            cbxSort.Items.Add("Billigaste");
            cbxSort.SelectedIndex = 0;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MainApp_Load(object sender, EventArgs e)
        {
            RefreshLBX();
            if (UserID == 0)
            {
                btnUsersAds.Hide();
                btnLogIn.Show();
            }
        }

        private void btnUsersAds_Click(object sender, EventArgs e)
        {
            MyAds myAds = new MyAds(UserID, _conn);
            myAds.Show();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            if (lbxShowResults.SelectedItem != null)
            {
                ads.GetInfoAboutAd(lbxShowResults.SelectedItem.ToString());
            }
            else
            {
                MessageBox.Show("Du behöver välja en annons först!");
            }
        }

        public void RefreshLBX()
        {
            lbxShowResults.Items.Clear();

            ToLBX = ads.GetAds(_conn);

            foreach (string str in ToLBX)
            {
                lbxShowResults.Items.Add(str);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RefreshLBX();
        }

        public void GetCategories()
        {
            List<string> Categories = ads.GetCategories();
            foreach (string str in Categories)
            {
                cbxCategory.Items.Add(str);
            }

        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            LogInWindow lw = new LogInWindow();
            lw.Show();
            this.Close();

        }
        //cbxSort.Items.Add("Senaste");
        //    cbxSort.Items.Add("Äldsta");
        //    cbxSort.Items.Add("Dyraste");
        //    cbxSort.Items.Add("Billgaste");
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sortBy = "";

            string category = "";
            string searchTerm = "";
            bool showAll = false;
            if (cbxSort.SelectedIndex == 0)
            {
                sortBy = " cost";
            }
            else if (cbxSort.SelectedIndex == 1)
            {
                sortBy = " cost desc";

            }
            else if (cbxSort.SelectedIndex == 2)
            {
                sortBy = " date desc";

            }
            else if (cbxSort.SelectedIndex == 3)
            {
                sortBy = " date";

            }


            if (cbxCategory.SelectedItem == null || cbxCategory.SelectedIndex == 1)
            {
                showAll = true;
            }
            else if (cbxCategory.SelectedItem != null && cbxCategory.SelectedItem.ToString() != "Alla Annonser")
            {
                category = cbxCategory.SelectedItem.ToString();
            }

            if (tbxSearchTerm.Text != "" && tbxSearchTerm.Text != "Sök...")
            {
                searchTerm = tbxSearchTerm.Text;
            }
            else
            {
                searchTerm = "";
            }


            ToLBX = ads.SearchAd(category, searchTerm, showAll,sortBy);
            lbxShowResults.Items.Clear();

            foreach (string str in ToLBX)
            {
                lbxShowResults.Items.Add(str);
            }

        }


    }
}
