﻿
namespace Annons_Applikation_Databasteknik
{
    partial class MyAds
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxViewMyAds = new System.Windows.Forms.ListBox();
            this.btnChange = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnNewAd = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxViewMyAds
            // 
            this.lbxViewMyAds.FormattingEnabled = true;
            this.lbxViewMyAds.ItemHeight = 15;
            this.lbxViewMyAds.Location = new System.Drawing.Point(0, 0);
            this.lbxViewMyAds.Name = "lbxViewMyAds";
            this.lbxViewMyAds.Size = new System.Drawing.Size(287, 454);
            this.lbxViewMyAds.TabIndex = 0;
            this.lbxViewMyAds.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(382, 16);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(82, 23);
            this.btnChange.TabIndex = 1;
            this.btnChange.Text = "Ändra vald";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(382, 45);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(82, 23);
            this.btnDel.TabIndex = 2;
            this.btnDel.Text = "Ta bort vald";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnNewAd
            // 
            this.btnNewAd.Location = new System.Drawing.Point(382, 71);
            this.btnNewAd.Name = "btnNewAd";
            this.btnNewAd.Size = new System.Drawing.Size(82, 23);
            this.btnNewAd.TabIndex = 3;
            this.btnNewAd.Text = "Skapa ny";
            this.btnNewAd.UseVisualStyleBackColor = true;
            this.btnNewAd.Click += new System.EventHandler(this.btnNewAd_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(382, 415);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(82, 23);
            this.btnRefresh.TabIndex = 4;
            this.btnRefresh.Text = "Uppdatera";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // MyAds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnNewAd);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.lbxViewMyAds);
            this.Name = "MyAds";
            this.Text = "MyAds";
            this.Load += new System.EventHandler(this.MyAds_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbxViewMyAds;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnNewAd;
        private System.Windows.Forms.Button btnRefresh;
    }
}