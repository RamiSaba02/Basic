﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Annons_Applikation_Databasteknik
{
    public partial class NewUserWindow : Form
    {
        public string _sqlConnectionStr = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        SqlConnection conn;
        public NewUserWindow()
        {
            conn = new SqlConnection(_sqlConnectionStr);
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {

            string newUsername = tbxUserName.Text;
            string Password = tbxPassword.Text;
            User user = new User(newUsername, Password, conn);
            if (tbxPassword.Text != tbxPassword2.Text)
            {
                MessageBox.Show("Your passwords do not match");
            }
            else if(tbxPassword.Text == tbxPassword2.Text)
            {
                user.AddNewUser();
            }

           

        }
    }
}
