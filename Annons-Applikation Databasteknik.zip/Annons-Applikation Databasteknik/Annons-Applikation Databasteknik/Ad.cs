﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace Annons_Applikation_Databasteknik
{
    class Ad
    {
        Connection connect = new Connection();

        public void EditAd(string title, string description, int cost, string category, int adID)
        {
            string edit_query = "Update userproduct Set title ='" + title + "', description = '" + description + "', cost = '" + cost + "', category = '" + category + "' where adID = '" + adID + "'";
            SqlConnection conn = connect.GetConn();
            SqlCommand cmd = new SqlCommand(edit_query, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            conn.Close();
            MessageBox.Show("Annons ändrad!!");

        }

        public List<string> SearchAd(string selectedCategory, string searchQuery, bool showAll, string orderBy)
        {
            List<string> sendToLbx = new List<string>();
            SqlConnection conn = connect.GetConn();
            string search_Query = "";
            if (showAll == true && searchQuery == "")
            {
                MessageBox.Show(orderBy);
                search_Query = "select * from userproduct Order By" + orderBy;

                sendToLbx = ExecuteQuery(search_Query);
            }

            else if (!showAll && searchQuery != "")
            {
                MessageBox.Show("nonull");
                search_Query = "select * from userproduct where category = '" + selectedCategory + "' and title = '" + searchQuery + "' Order By "  + orderBy ;
                sendToLbx = ExecuteQuery(search_Query);
            }
            else if (!showAll && searchQuery == "")
            {
                MessageBox.Show(selectedCategory);
                search_Query = "select * from userproduct where category = '" + selectedCategory + "' Order By " + orderBy;
                sendToLbx = ExecuteQuery(search_Query);
            }
            else if (showAll && searchQuery != "")
            {
                MessageBox.Show(searchQuery);
                search_Query = "select * from userproduct where title = '" + searchQuery + "' Order By " + orderBy;
                sendToLbx = ExecuteQuery(search_Query);
            }
            return sendToLbx;
        }

        public void AddNewAd(string title, string description, int cost, string category, SqlConnection conn, int userID)
        {
            string insert_query = "insert into userproduct (title,description,cost,category,userid) values ('" + title.Trim() + "','" + description + "','" + cost + "','" + category + "','" + userID + "')";

            SqlCommand cmd = new SqlCommand(insert_query, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            conn.Close();
            MessageBox.Show("Annons tillagd!");
        }
        public void RemoveAd(int adID)
        {
            SqlConnection conn = connect.GetConn();
            string delete_query = "DELETE FROM userproduct WHERE adID = '" + adID + "'";
            SqlCommand cmd = new SqlCommand(delete_query, conn);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Annons Borttagen!");

        }


        public List<string> GetAds(SqlConnection conn)
        {

            List<string> sendToLbx = new List<string>();
            using (SqlCommand cmd = new SqlCommand("Select * from userproduct", conn))
            {
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        sendToLbx.Add("nr: " + reader.GetValue("adid") + " | Pris: " + reader.GetValue("cost") + " kr    Rubrik: " + reader.GetValue("title"));
                    }
                }
                conn.Close();

            }
            return sendToLbx;
        }

        public void GetInfoAboutAd(string selectedItem)
        {
            SqlConnection conn = connect.GetConn();
            int adID = GetAdID(selectedItem);

            using (SqlCommand cmd = new SqlCommand("Select * from userproduct where AdID = '" + adID + "'", conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string Message = "Rubrik: " + reader.GetValue("title") + "\nBeskrivning: " + reader.GetValue("description") + "\nKategori: " + reader.GetValue("category") + "\nPris: " + reader.GetValue("cost");
                        MessageBox.Show(Message, "ProduktInformation");
                    }
                }

                conn.Close();
            }



        }
        public List<string> GetMyAds(SqlConnection conn, int userID)
        {
            List<string> sendToLbx = new List<string>();
            using (SqlCommand cmd = new SqlCommand("Select * from userproduct where userID = '" + userID + "'", conn))
            {
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        sendToLbx.Add("nr: " + reader.GetValue("adid") + " | Pris: " + reader.GetValue("cost") + " kr    Rubrik: " + reader.GetValue("title"));
                    }
                }
                conn.Close();

            }
            return sendToLbx;
        }

        public List<string> GetCategories()
        {
            Connection connect = new Connection();
            SqlConnection conn = connect.GetConn();
            List<string> sendToCbx = new List<string>();

            using (SqlCommand cmd = new SqlCommand("Select * from Categories", conn))
            {
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader()
)
                {
                    while (reader.Read())
                    {
                        sendToCbx.Add(reader.GetValue("category").ToString());
                    }
                }
                conn.Close();

            }

            return sendToCbx;

        }

        public int GetAdID(string selectedItem)
        {
            string[] getIndex = selectedItem.Split(' ');

            string AdID = getIndex[1];
            int AdIDToInt = int.Parse(AdID);
            return AdIDToInt;
        }

        public List<string> ExecuteQuery(string query)
        {
            SqlConnection conn = connect.GetConn();
            List<string> sendToLbx = new List<string>();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        sendToLbx.Add("nr: " + reader.GetValue("adid") + " | Pris: " + reader.GetValue("cost") + " kr    Rubrik: " + reader.GetValue("title"));
                    }
                }
                conn.Close();

            }
            return sendToLbx;
        }



    }



}

