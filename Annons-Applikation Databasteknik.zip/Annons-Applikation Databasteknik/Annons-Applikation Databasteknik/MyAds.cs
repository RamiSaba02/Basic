﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Annons_Applikation_Databasteknik
{
    public partial class MyAds : Form
    {
        public SqlConnection conn { get; set; }
        public int _userID { get; set; }
        Ad ads = new Ad();
        public MyAds(int userID, SqlConnection _conn)
        {
            conn = _conn;
            _userID = userID; 
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            int adID = 0;


            if (lbxViewMyAds.SelectedItem != null)
            {
                adID = ads.GetAdID(lbxViewMyAds.SelectedItem.ToString());
                EditAd ea = new EditAd(adID);

                ea.Show();
            }
            else
            {
                MessageBox.Show("Du måste välja vilken du vill ändra");
            }
           
        }

        private void MyAds_Load(object sender, EventArgs e)
        {
            RefreshLBX();
        }

        private void btnNewAd_Click(object sender, EventArgs e)
        {
            AddAd addad = new AddAd(_userID);
            addad.Show();
        }

        public void RefreshLBX()
        {
            lbxViewMyAds.Items.Clear();
            List<string> ToLBX = ads.GetMyAds(conn,_userID);

            foreach (string str in ToLBX)
            {
                lbxViewMyAds.Items.Add(str);
            }

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshLBX();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            int adID = 0;
            adID = ads.GetAdID(lbxViewMyAds.SelectedItem.ToString());


            if (adID != 0)
            {

                ads.RemoveAd(adID);
                RefreshLBX();
            }
            else
            {
                MessageBox.Show("Du måste välja en annons först!");
            }
        }
    }
}
