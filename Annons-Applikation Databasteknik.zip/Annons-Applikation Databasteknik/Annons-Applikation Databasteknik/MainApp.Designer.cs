﻿
namespace Annons_Applikation_Databasteknik
{
    partial class MainApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxCategory = new System.Windows.Forms.ComboBox();
            this.tbxSearchTerm = new System.Windows.Forms.TextBox();
            this.lbxShowResults = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnUsersAds = new System.Windows.Forms.Button();
            this.btnInfo = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLogIn = new System.Windows.Forms.Button();
            this.cbxSort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbxCategory
            // 
            this.cbxCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCategory.FormattingEnabled = true;
            this.cbxCategory.Location = new System.Drawing.Point(466, 48);
            this.cbxCategory.Name = "cbxCategory";
            this.cbxCategory.Size = new System.Drawing.Size(121, 23);
            this.cbxCategory.Sorted = true;
            this.cbxCategory.TabIndex = 0;
            // 
            // tbxSearchTerm
            // 
            this.tbxSearchTerm.Location = new System.Drawing.Point(466, 12);
            this.tbxSearchTerm.Name = "tbxSearchTerm";
            this.tbxSearchTerm.Size = new System.Drawing.Size(121, 23);
            this.tbxSearchTerm.TabIndex = 1;
            this.tbxSearchTerm.Text = "Sök...";
            // 
            // lbxShowResults
            // 
            this.lbxShowResults.FormattingEnabled = true;
            this.lbxShowResults.ItemHeight = 15;
            this.lbxShowResults.Location = new System.Drawing.Point(103, 77);
            this.lbxShowResults.Name = "lbxShowResults";
            this.lbxShowResults.Size = new System.Drawing.Size(484, 289);
            this.lbxShowResults.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(608, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Kategori";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(608, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Sök";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnUsersAds
            // 
            this.btnUsersAds.Location = new System.Drawing.Point(608, 343);
            this.btnUsersAds.Name = "btnUsersAds";
            this.btnUsersAds.Size = new System.Drawing.Size(101, 23);
            this.btnUsersAds.TabIndex = 6;
            this.btnUsersAds.Text = "Mina annonser";
            this.btnUsersAds.UseVisualStyleBackColor = true;
            this.btnUsersAds.Click += new System.EventHandler(this.btnUsersAds_Click);
            // 
            // btnInfo
            // 
            this.btnInfo.Location = new System.Drawing.Point(608, 77);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(152, 23);
            this.btnInfo.TabIndex = 7;
            this.btnInfo.Text = "Mer info om vald annons";
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(608, 181);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Hämta nya annonser";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLogIn
            // 
            this.btnLogIn.Location = new System.Drawing.Point(619, 343);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.Size = new System.Drawing.Size(75, 23);
            this.btnLogIn.TabIndex = 9;
            this.btnLogIn.Text = "Logga in";
            this.btnLogIn.UseVisualStyleBackColor = true;
            this.btnLogIn.Visible = false;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // cbxSort
            // 
            this.cbxSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSort.FormattingEnabled = true;
            this.cbxSort.Location = new System.Drawing.Point(180, 48);
            this.cbxSort.Name = "cbxSort";
            this.cbxSort.Size = new System.Drawing.Size(121, 23);
            this.cbxSort.Sorted = true;
            this.cbxSort.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(103, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "Sortera efter";
            // 
            // MainApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbxSort);
            this.Controls.Add(this.btnLogIn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnInfo);
            this.Controls.Add(this.btnUsersAds);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbxShowResults);
            this.Controls.Add(this.tbxSearchTerm);
            this.Controls.Add(this.cbxCategory);
            this.Name = "MainApp";
            this.Text = "MainApp";
            this.Load += new System.EventHandler(this.MainApp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxCategory;
        private System.Windows.Forms.TextBox tbxSearchTerm;
        private System.Windows.Forms.ListBox lbxShowResults;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnUsersAds;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnLogIn;
        private System.Windows.Forms.ComboBox cbxSort;
        private System.Windows.Forms.Label label1;
    }
}