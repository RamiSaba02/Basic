﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace Annons_Applikation_Databasteknik
{
    class User
    {

        private string _username;
        private string _password;
        private SqlConnection _conn;
        public User(string username, string password, SqlConnection conn)
        {
            _username = username;
            _password = password;
            _conn = conn;
        }

        public void  AddNewUser()
        {
            try
            {
                SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[User] ([username]  ,[password])  VALUES    ('" + _username.Trim() + "', '" + _password.Trim() + "')", _conn);
                _conn.Open();

                cmd.ExecuteNonQuery();
                NewUserWindow nuw = new NewUserWindow();
                nuw.Close();
                _conn.Close();
                MessageBox.Show("New account created!");
                




            }
            catch (Exception ex) //Catch Other Exception
            {
                MessageBox.Show("The username is taken, try a different one.");
                _conn.Close();
            }
        }

        public int CheckLoginInfo()
        {
            _conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(1) FROM [dbo].[User] WHERE username = '" + _username + "' AND password = '" + _password + "'", _conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            _conn.Close();
            if (dt.Rows[0][0].ToString() == "1")
            {
                MessageBox.Show("Successfully logged in");
                return GetUserID(_username);
            }
            else
            {
                MessageBox.Show("Username or Password is incorrect");
                return 0;
            }
        }
        public int GetUserID(string username)
        {
            
            _conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT Id FROM [dbo].[User] WHERE username = '" + _username + "'", _conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            _conn.Close();
            string userID = dt.Rows[0][0].ToString();
            int ID = int.Parse(userID);
            return ID;
            
        }
    }
}
