﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Annons_Applikation_Databasteknik
{
    public partial class EditAd : Form
    {
        public int AdID { get; set; }
        Ad ads = new Ad();
        public EditAd(int AdId)
        {
            InitializeComponent();
            AdID = AdId;
            DisplayCategories();
            GetInfoTotbx();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ads.EditAd(tbxCaption.Text.Trim(), tbxDescription.Text.Trim(), int.Parse(tbxPrice.Text), cbxCategories.SelectedItem.ToString(), AdID);
        }
        public void DisplayCategories()
        {
            List<string> ShowToCbx = ads.GetCategories();
            foreach (string str in ShowToCbx)
            {
                cbxCategories.Items.Add(str);
            }

        }

        public void GetInfoTotbx()
        {
            Connection connect = new Connection();
            SqlConnection conn = connect.GetConn();
            using (SqlCommand cmd = new SqlCommand("Select * from userproduct where adID = '" + AdID + "'", conn))
            {
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tbxCaption.Text = reader.GetValue("title").ToString();
                        tbxDescription.Text = reader.GetValue("description").ToString();
                        tbxPrice.Text = reader.GetValue("cost").ToString();
                        cbxCategories.Text = reader.GetValue("Category").ToString();
                    }
                }

            }
            conn.Close();

        }

    }

}

